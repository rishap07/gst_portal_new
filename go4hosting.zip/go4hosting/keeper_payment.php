<?php
//echo "<pre>";
//var_dump($_POST);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<script type="text/javascript">
function submitToPaypal()
{
	document.Form2.action='https://secure.ebs.in/pg/ma/payment/request';
	document.Form2.submit();
}
</script>
<style type="text/css">
marquee{
	margin-top:20%;
	font-family:Arial, Helvetica, sans-serif;
	font-size:18px;
	font-weight:bold;
}
</style>
</head>
<body onload="submitToPaypal();">
	<div>
	   <table>
		  <tr>
			<td>
				<MARQUEE>
					Please wait while we direct you to secure payment page	
				</MARQUEE> 
			</td>
		  </tr>
		</table>
	</div>
<?php 
ini_set('display_errors',1);
error_reporting(E_ALL);

$hashData = "e21158bc40562aaf6c013b08be891b26";
$hashData = $hashData."|".urlencode('9006')."|".urlencode($_POST['amount'])."|".urlencode($_POST['reference_no'])."|".$_POST['return_url']."|".urlencode('LIVE');
unset($_POST['submitted']);
ksort($_POST);
/*foreach ($_POST as $key => $value){
	if (strlen($value) > 0) {
		$hashData .= '|'.$value;
	}
}*/
if (strlen($hashData) > 0) {
	$secure_hash = md5($hashData);
}
//echo $hashData;
//print_r($secure_hash_md5); exit;
?>
<form action="https://secure.ebs.in/pg/ma/payment/request" name="Form2" method="POST">
<input type="hidden" value="9006" name="account_id"/>
<input type="hidden" value="<?php echo $_POST['amount']; ?>" name="amount"/>
<input type="hidden" value="0" name="channel"/>
<input type="hidden" value="<?php echo $_POST['name']; ?>" name="name"/>
<input type="hidden" value="jaipur" name="address"/>
<input type="hidden" value="jaipur" name="city"/>
<input type="hidden" value="IN" name="country"/>
<input type="hidden" value="302022" name="postal_code"/>
<input type="hidden" value="INR" name="currency"/>
<input type="hidden" value="<?php echo $_POST['phone'];?>" name="phone"/>
<input type="hidden" value="<?php echo $_POST['email']; ?>" name="email"/>
<input type="hidden" value="Payment information from GST" name="description"/>
<input type="hidden" value="GBP" name="display_currency"/>
<input type="hidden" value="1" name="display_currency_rates"/>
<input type="hidden" value="LIVE" name="mode"/>
<input type="hidden" value="<?php echo $_POST['reference_no']; ?>" name="reference_no"/>
<input type="hidden" value="<?php echo $_POST['return_url']; ?>" name="return_url"/>
<input type="hidden" value="<?php echo $secure_hash ?>" name="secure_hash"/>


<!--
<input type="hidden" value="<?php echo $_POST['account_id'];?>" name="account_id"/>
<input type="hidden" value="<?php echo $_POST['address'];?>" name="address"/>
<input type="hidden" value="<?php echo $_POST['amount'];?>" name="amount"/>
<input type="hidden" value="<?php echo $_POST['bank_code'];?>" name="bank_code"/>
<input type="hidden" value="<?php echo $_POST['card_brand'];?>" name="card_brand"/>
<input type="hidden" value="<?php echo $_POST['channel'];?>" name="channel"/>
<input type="hidden" value="<?php echo $_POST['city'];?>" name="city"/>
<input type="hidden" value="<?php echo $_POST['country'];?>" name="country"/>
<input type="hidden" value="<?php echo $_POST['currency'];?>" name="currency"/>
<input type="hidden" value="<?php echo $_POST['description'];?>" name="description"/>
<input type="hidden" value="<?php echo $_POST['display_currency'];?>" name="display_currency"/>
<input type="hidden" value="<?php echo $_POST['display_currency_rates'];?>" name="display_currency_rates"/>
<input type="hidden" value="<?php echo $_POST['email'];?>" name="email"/>
<input type="hidden" value="<?php echo $_POST['emi'];?>" name="emi"/>
<input type="hidden" value="<?php echo $_POST['mode'];?>" name="mode"/>
<input type="hidden" value="<?php echo $_POST['name'];?>" name="name"/>
<input type="hidden" value="<?php echo $_POST['page_id'];?>" name="page_id"/>
<input type="hidden" value="<?php echo $_POST['payment_mode'];?>" name="payment_mode"/>
<input type="hidden" value="<?php echo $_POST['payment_option'];?>" name="payment_option"/>
<input type="hidden" value="<?php echo $_POST['phone'];?>" name="phone"/>
<input type="hidden" value="<?php echo $_POST['postal_code'];?>" name="postal_code"/>
<input type="hidden" value="<?php echo $_POST['reference_no'];?>" name="reference_no"/>
<input type="hidden" value="<?php echo $_POST['return_url']; ?>" name="return_url"/>
<input type="hidden" value="<?php echo $_POST['ship_address'];?>" name="ship_address"/>
<input type="hidden" value="<?php echo $_POST['ship_city'];?>" name="ship_city"/>
<input type="hidden" value="<?php echo $_POST['ship_country'];?>" name="ship_country"/>
<input type="hidden" value="<?php echo $_POST['ship_name'];?>" name="ship_name"/>
<input type="hidden" value="<?php echo $_POST['ship_phone'];?>" name="ship_phone"/>
<input type="hidden" value="<?php echo $_POST['ship_postal_code'];?>" name="ship_postal_code"/>
<input type="hidden" value="<?php echo $_POST['ship_state'];?>" name="ship_state"/>
<input type="hidden" value="<?php echo $_POST['state'];?>" name="state"/>
<input type="hidden" value="<?php echo $secure_hash; ?>" name="secure_hash"/>-->
</form>