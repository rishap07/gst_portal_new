<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<script type="text/javascript">
function submitToPaypal()
{
    
	document.Form2.action='https://secure.ebs.in/pg/ma/payment/request';//'https://secure.ebs.in/pg/ma/sale/pay/';
	//document.Form2.action='https://sandbox.paypal.com/cgi-bin/webscr';
	document.Form2.submit();
}
</script>
<style type="text/css">
marquee{
		margin-top:20%;
		font-family:Arial, Helvetica, sans-serif;
		font-size:18px;
		font-weight:bold;
		}
</style>
</head>
<body onload="submitToPaypal();">
<?php 
//require('/var/www/html/ws/adm/init.php');
if($_REQUEST['currenct_type']=='INR')
	{
	$Amount = $_REQUEST['total'];
	}
	else{
            /*$q = mysql_query("select * from  tblcurrencies where code='INR'");
            $rate =68;
            while ($row = mysql_fetch_array($q))
            {
                $rate = $row['rate'];
            }*/
            $Amount = $_REQUEST['total']*68;
	}
?>
<?php

$dataArr = $_POST;
$dataArr['amount']=$Amount;
$ref_id = date('siHmdy');
$hashData = "e21158bc40562aaf6c013b08be891b26"; //Pass your Registered Secret Key
$Redirect_Url= 'http://www.go4hosting.com/go4hosting/response.php?DR={DR}';
//$Redirect_Url= 'http://www.go4hosting.com/thank-you-payment.htm';
$hash = $hashData."|".urlencode('9006')."|".urlencode($Amount)."|".urlencode($ref_id)."|".$Redirect_Url."|".urlencode('LIVE');

$secure_hash = md5($hash); 
?>
<form Name="Form2" method="post">
	<div>
	   <table>
		  <tr>
			<td>
				<MARQUEE>
					Please wait while we direct you to secure payment page	
				</MARQUEE> 
			</td>
		  </tr>
		</table>
            
	</div>

	<input type="hidden" value="9006" name="account_id"/>
    <input type="hidden" value="<?php echo $Amount ?>" name="amount"/>
    <input type="hidden" value="0" name="channel"/>
    <input type="hidden" name="name" value="<?=$_REQUEST['s_firstname'];?> <?=$_REQUEST['s_middlename'];?> <?=$_REQUEST['s_lastname'];?>">
	 <input type="hidden" name="address" value="<?=$_REQUEST['s_address'];?>">  
	 <input type="hidden" name="city" value="<?=$_REQUEST['s_city'];?>">  
	 <input type="hidden" name="state" value="<?=$_REQUEST['s_state'];?>">  
	 <input type="hidden" name="postal_code" value="<?=$_REQUEST['s_zip'];?>">  
	 <input type="hidden" name="country" value="<?=$_REQUEST['s_country'];?>">  
	 <input type="hidden" name="phone" value="<?=$_REQUEST['s_tel'];?>">  
	 <input type="hidden" name="email" value="<?=$_REQUEST['email'];?>"> 
    <input type="hidden" value="<?=$_REQUEST['currenct_type'];?>" name="currency"/>
    <input type="hidden" value="Payment from Go4hosting" name="description"/>
    <input type="hidden" value="GBP" name="display_currency"/>
    <input type="hidden" value="1" name="display_currency_rates"/>
    <input type="hidden" value="LIVE" name="mode"/>
    <input type="hidden" value="<?php echo $ref_id; ?>" name="reference_no"/>
    <input type="hidden" value="<?php echo $Redirect_Url; ?>" name="return_url"/>
    <input type="hidden" value="<?php echo $secure_hash ?>" name="secure_hash"/>
</form>
</body>
</html>